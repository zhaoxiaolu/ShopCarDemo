//
//  UIViewController+ExtendCtr.h
//  RealWriteProBaiSI
//
//  Created by zhang on 16/10/31.
//  Copyright © 2016年 zhang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (ExtendCtr)


/**
 *  显示遮罩
 */
-(void)loadHudShowLoading;

/**
 *  隐藏遮罩
 */

-(void)hiddenHud;

@end
