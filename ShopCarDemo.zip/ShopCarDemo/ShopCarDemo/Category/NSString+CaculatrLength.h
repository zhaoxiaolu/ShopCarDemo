//
//  NSString+CaculatrLength.h
//  YourBigJb
//
//  Created by zhang on 16/9/20.
//  Copyright © 2016年 zhang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (CaculatrLength)

-(CGSize)caculateStrLength:(NSString *)str;

@end
