//
//  AppDelegate.h
//  ShopCarDemo
//
//  Created by zhang on 16/12/8.
//  Copyright © 2016年 zhang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

