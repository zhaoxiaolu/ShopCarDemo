//
//  ToolLab.h
//  YourBigJb
//
//  Created by zhang on 16/9/19.
//  Copyright © 2016年 zhang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ToolLab : UILabel

@end

@interface NavTitleViewLab : ToolLab

+(instancetype)titleViewWithTitle:(NSString *)title;
@end


