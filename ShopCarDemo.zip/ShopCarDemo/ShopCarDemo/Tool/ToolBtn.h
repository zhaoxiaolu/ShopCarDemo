//
//  ToolBtn.h
//  GuoJi Bluetooth
//
//  Created by zhang on 16/10/13.
//  Copyright © 2016年 zhang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ToolBtn : UIButton

@end


/**
 *  image在上，lab在下
 */
@interface NavEditerBtn : UIButton

@end
